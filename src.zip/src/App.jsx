// App.jsx
import React from 'react';
import Gutunganywa from './GutunganywaIsoko';

function App() {
  return (
    <div className="App">
      <Gutunganywa/>
    </div>
  );
}

export default App;
