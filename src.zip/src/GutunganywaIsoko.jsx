
import React from 'react';

const Gutunganywa = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Your report has been submitted");
    e.target.reset();
     
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto p-4">
        <h2 className="text-2xl font-bold text-indigo-700 mb-4 text-center">
        Amakuru Y'ifu Zagiye Kw'isoko
        </h2>
        
        <form onSubmit={handleSubmit} className="bg-indigo-50 p-4 md:p-6 rounded-lg shadow-lg">

           {/* Row 1: Date, Amafaranga Arava K'wisoko, Amafaranga Asigaye */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <label className="block text-indigo-700 font-medium mb-2">
            Date
            <input 
              type="date" 
              name="date" 
              className="mt-1 p-2 w-full border rounded bg-indigo-50"
              required 
            />
          </label>

          <label className="block text-indigo-700 font-medium mb-2">
            Amafaranga Arava K'wisoko
            <input 
              type="number" 
              name="amafaranga_arava_kwisoko" 
              className="mt-1 p-2 w-full border rounded bg-indigo-50"
              required 
            />
          </label>

          <label className="block text-indigo-700 font-medium mb-2">
            Amafaranga Asigaye
            <input 
              type="number" 
              name="amafaranga_asigaye" 
              className="mt-1 p-2 w-full border rounded bg-indigo-50"
              required 
            />
          </label>
        </div>

        {/* Row 2: Nimero Y'umufuka, Umucuruzi, Ugemuye K'wisoko */}
        <div className="grid grid-cols-3 gap-4 mb-4 font-medium mb-2">
          <label className="block text-indigo-700">
            Nimero Y'umufuka
            <input 
              type="text" 
              name="nimero_yumufuka" 
              className="mt-1 p-2 w-full border rounded bg-indigo-50"
              required 
            />
          </label>

          <label className="block text-indigo-700 font-medium mb-2">
            Umucuruzi
            <input 
              type="text" 
              name="umucuruzi" 
              className="mt-1 p-2 w-full border rounded bg-indigo-50"
              required 
            />
          </label>

          <label className="block text-indigo-700 font-medium mb-2">
            Ugemuye K'wisoko
            <input 
              type="text" 
              name="ugemuye_kwisoko" 
              className="mt-1 p-2 w-full border rounded bg-indigo-50"
              required 
            />
          </label>
        </div>

        {/* Row 3: Ukoze Raporo on the left side */}
        <div className="mb-4">
          <label className="block text-indigo-700 font-medium mb-2">
            Ukoze Raporo
            <input 
              type="text" 
              name="ukoze_raporo" 
              className="mt-1 p-2 w-1/3 border rounded bg-indigo-50"
              required 
            />
          </label>
        </div>

        
         
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      
            <div>
              <h2 className="text-center text-white bg-indigo-500 py-2 font-semibold">NEW FOOD</h2>
              <div className="grid grid-cols-4 gap-2">
                <p className="text-center text-indigo-600 font-medium">Ibiro</p>
                <p className="text-center text-indigo-600 font-medium">Imifuka</p>
                <p className="text-center text-indigo-600 font-medium">Price/umufuka</p>
                <p className="text-center text-indigo-600 font-medium">Total/imifuka</p>
                <input
                      type="text"
                      placeholder="NF:25"
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                     <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                
                   
                <input
                      type="number"
                      placeholder="NF:5"
                      className="bg-gray-200 p-2 rounded"
                     
                    />
                     <input
                      type="number"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                     
                    />
                    
                    <input
                      type="text"
                      placeholder=""
                      
                      className="bg-gray-200 p-2 rounded"
                      required
                    />
                    <input
                      type="text"
                      placeholder=""
                      
                      className="bg-gray-200 p-2 rounded"
                      required
                    />

                <p className="col-span-2 text-left font-bold text-indigo-600">
                  Total: KG
                </p>
              </div>
            </div>

            <div>
              <h2 className="text-center text-white bg-indigo-500 py-2 font-semibold">IFUNGURO</h2>
              <div className="grid grid-cols-4 gap-2">
                <p className="text-center text-indigo-600 font-medium ">Ibiro</p>
                <p className="text-center text-indigo-600 font-medium ">Imifuka</p>
                <p className="text-center text-indigo-600 font-medium ">Price/umufuka</p>
                <p className="text-center text-indigo-600 font-medium ">Total/imifuka</p>
                
                    <input
                      type="text"
                      placeholder="IF:25"
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                     <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                     <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                
                <p className="col-span-2 text-left font-bold text-indigo-600">
                  Total: KG
                </p>
              </div>
            </div>

      
            <div>
              <h2 className="text-center text-white bg-indigo-500 py-2 font-semibold">ISEZERANO</h2>
              <div className="grid grid-cols-4 gap-2">
                <p className="text-center text-indigo-600 font-medium">Ibiro</p>
                <p className="text-center text-indigo-600 font-medium">Imifuka</p>
                <p className="text-center text-indigo-600 font-medium">Price/umufuka</p>
                <p className="text-center text-indigo-600 font-medium">total/imifuka</p>
                <input
                      type="text"
                      placeholder="IS:25KG"
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                     <input
                      type="number"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                     
                    />
                     <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                     
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                  
                
                <p className="col-span-2 text-left font-bold text-indigo-600">
                  Total: KG
                </p>
              </div>
            </div>

          
            <div>
              <h2 className="text-center text-white bg-indigo-500 py-2 font-semibold">MAGAJU</h2>
              <div className="grid grid-cols-4 gap-2">
                <p className="text-center text-indigo-600 font-medium">Ibiro</p>
                <p className="text-center text-indigo-600 font-medium">Imifuka</p>
                <p className="text-center text-indigo-600 font-medium">Price/umufuka</p>
                <p className="text-center text-indigo-600 font-medium">total/imifuka</p>
                    <input
                      type="text"
                      placeholder="MG:25KG"
                      className="bg-gray-200 p-2 rounded"
                     required
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                    
                    />
                     <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                     <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                      
                    />
                  
                
                <p className="col-span-2 text-left font-bold text-indigo-600">
                  Total: KG
                </p>
              </div>

              
            </div>
            <div>
              <h2 className="text-center text-white bg-indigo-500 py-2 font-semibold">ISEZERANO ENVELOPE 5KG</h2>
              <div className="grid grid-cols-4 gap-2">
                <p className="text-center text-indigo-600 font-medium">Ibiro</p>
                <p className="text-center text-indigo-600 font-medium">Imifuka</p>
                <p className="text-center text-indigo-600 font-medium">Price/umufuka</p>
                <p className="text-center text-indigo-600 font-medium">total/imifuka</p>
                    <input
                      type="text"
                      placeholder="IS:5KG"
                      className="bg-gray-200 p-2 rounded"
                     required
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                    />
                    <input
                      type="text"
                      placeholder=""
                      className="bg-gray-200 p-2 rounded"
                    />
                    </div>
                    </div>
                    
                    <label className="block text-indigo-700 mb-4 font-medium mb-2">
          Comment
          <textarea 
            name="comment" 
            className="mt-1 p-2 w-full border rounded bg-indigo-50" 
            rows="3"
          ></textarea>
          

        </label>

                


          </div>
          <button 
          type="submit"
          className="w-full mt-4 p-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
        >
          Submit
        </button>
         
</form>
</div>
</div>

  );
                };
export default Gutunganywa;
